Klim Type Foundry test fonts

Use these test fonts to mock up your print, web or app designs for approval before licensing the full versions.

This download includes:
- All of our retail fonts as OTF and WOFF2
- Some of our retail fonts as Variable Fonts (VF) TTF and WOFF2

Our test font family names are prefixed with “Test”.

Test fonts have no OpenType features and a limited character set:

ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
0123456789 .,-

By using these fonts you agree to our Test Font Licence Agreement.
